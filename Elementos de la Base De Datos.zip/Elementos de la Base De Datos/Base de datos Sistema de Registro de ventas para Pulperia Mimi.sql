-- ==========================================
-- CREAR BASE DE DATOS
-- ==========================================

Create database SistemaRegistroDeVentasBD;
GO

USE SistemaRegistroDeVentasBD;
GO

-- ==========================================
-- TABLA CLIENTE
-- ==========================================

Create table Cliente (
id_cliente INT IDENTITY(1,1) PRIMARY KEY,
nombre VARCHAR(50) NOT NULL,
apellido VARCHAR(50) NOT NULL,
telefono VARCHAR(15),
direccion VARCHAR(100)
);
GO

-- ==========================================
-- TABLA EMPLEADO
-- ==========================================

Create table Empleado (
id_empleado INT IDENTITY(1,1) PRIMARY KEY,
nombre VARCHAR(50) NOT NULL,
telefono VARCHAR(15),
cargo VARCHAR(50),
fecha_contratacion DATE,
salario DECIMAL(10,2),
estado VARCHAR(20)
);
GO

-- ==========================================
-- TABLA PROVEEDOR
-- ==========================================

Create table Proveedor (
id_proveedor INT IDENTITY(1,1) PRIMARY KEY,
nombre_empresa VARCHAR(100) NOT NULL,
direccion VARCHAR(100),
telefono VARCHAR(15),
correo_electronico VARCHAR(100),
cedula VARCHAR(25)
);
GO


-- ==========================================
-- TABLA CATEGORIA
-- ==========================================

Create table Categoria (
id_categoria INT IDENTITY(1,1) PRIMARY KEY,
nombre_categoria VARCHAR(50) NOT NULL,
descripcion VARCHAR(100)
);
GO

-- ==========================================
-- TABLA PRODUCTO
-- ==========================================
 CREATE TABLE Producto (
    id_producto INT IDENTITY(1,1) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10, 2),
    stock INT,
    fecha_vencimiento DATE,
    id_categoria INT,
    FOREIGN KEY (id_categoria) REFERENCES Categoria(id_categoria)
);
GO


-- ==========================================
-- TABLA VENTA
-- ==========================================

Create table Venta (
id_venta INT IDENTITY(1,1) PRIMARY KEY,
fecha DATE,
total DECIMAL(10,2),
metodo_pago VARCHAR(30),
impuesto DECIMAL(10,2),
descuento DECIMAL(10,2),
id_cliente INT,
id_empleado INT,
FOREIGN KEY (id_cliente) REFERENCES Cliente(id_cliente),
FOREIGN KEY (id_empleado) REFERENCES Empleado(id_empleado)
);
GO

-- ==========================================
-- TABLA DETALLEVENTA
-- ==========================================

Create table DetalleVenta (
id_detalle_venta INT IDENTITY(1,1) PRIMARY KEY,
nombre_producto VARCHAR(100),
cantidad INT,
precio_unitario DECIMAL(10,2),
subtotal DECIMAL(10,2),
descuento_aplicado DECIMAL(10,2),
id_venta INT,
id_producto INT,
FOREIGN KEY (id_venta) REFERENCES Venta(id_venta),
FOREIGN KEY (id_producto) REFERENCES Producto(id_producto)
);
GO

-- ==========================================
-- TABLA COMPRA
-- ==========================================

Create table Compra (
id_compra INT IDENTITY(1,1) PRIMARY KEY,
fecha_compra DATE,
total_compra DECIMAL(10,2),
id_empleado INT,
id_proveedor INT,
FOREIGN KEY (id_empleado) REFERENCES Empleado(id_empleado),
FOREIGN KEY (id_proveedor) REFERENCES Proveedor(id_proveedor)
);
GO

-- ==========================================
-- TABLA DETALLECOMPRA
-- ==========================================

Create table DetalleCompra (
id_detalle_compra INT IDENTITY(1,1) PRIMARY KEY,
nombre_producto VARCHAR(100), 
cantidad_compra INT,
precio_unitario DECIMAL(10,2),
subtotal DECIMAL(10,2),
id_compra INT,
FOREIGN KEY (id_compra) REFERENCES Compra(id_compra)
);
GO

-- ==========================================
-- TABLA USUARIO
-- ==========================================

CREATE TABLE Usuario
(
    id_usuario INT IDENTITY(1,1) PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    password_salt VARCHAR(255) NOT NULL,
    activo BIT DEFAULT 1,
    intentos_fallidos INT DEFAULT 0,
    bloqueado_hasta DATETIME NULL
);

-- ==========================================
-- Insert Usuario USUARIO
-- ==========================================
INSERT INTO Usuario
(
    usuario,
    password_hash,
    password_salt
)
VALUES
(
    'Darling',
    'y+S4w1EGninc0NBSMaXxOONpU9uosy1xKAPNcgviUos=',
    '3w6P5Zw9tk7hYakiT/BsmA=='
);



-- ==========================================
-- DATOS DE PRUEBA
-- ==========================================

INSERT INTO Categoria (nombre_categoria, descripcion)
VALUES ('Bebidas', 'Refrescos y bebidas');
GO

INSERT INTO Cliente (nombre, apellido, telefono, direccion)
VALUES ('Juan', 'Perez', '88888888', 'Granada');
GO

INSERT INTO Empleado (nombre, telefono, cargo, fecha_contratacion, salario, estado)
VALUES ('Maria Lopez', '88887777', 'Cajera', '2025-01-15', 9500.00, 'Activo');
GO

INSERT INTO Proveedor (nombre_empresa, direccion, telefono, correo_electronico, cedula)
VALUES ('Distribuidora Central', 'Managua', '22223333', '[ventas@central.com](mailto:ventas@central.com)', '001-123456-0001A');
GO

INSERT INTO Producto (nombre, precio, stock, fecha_vencimiento, id_categoria)
VALUES ('Coca Cola 600ml', 45.00, 120, '2027-01-01', 1);
GO

INSERT INTO Venta (fecha, total, metodo_pago, impuesto, descuento, id_cliente, id_empleado)
VALUES (GETDATE(), 45.00, 'Efectivo', 0, 0, 1, 1);
GO

INSERT INTO DetalleVenta
(nombre_producto, cantidad, precio_unitario, subtotal, descuento_aplicado, id_venta, id_producto)
VALUES
('Coca Cola 600ml', 1, 45.00, 45.00, 0, 1, 1);
GO

INSERT INTO Compra
(fecha_compra, total_compra, id_empleado, id_proveedor)
VALUES
(GETDATE(), 3840.00, 1, 1);
GO

INSERT INTO DetalleCompra
(nombre_producto, cantidad_compra, precio_unitario, subtotal, id_compra)
VALUES
('Coca Cola 600ml', 120, 32.00, 3840.00, 1);
GO

-- ==========================================
-- CONSULTA CLIENTE
-- ==========================================

SELECT
C.id_cliente,
C.nombre,
C.apellido,
V.id_venta,
V.total
FROM Cliente C
LEFT JOIN Venta V
ON C.id_cliente = V.id_cliente;
GO

-- ==========================================
-- CONSULTA EMPLEADO
-- ==========================================

SELECT
E.id_empleado,
E.nombre,
E.cargo,
V.id_venta,
V.total
FROM Empleado E
LEFT JOIN Venta V
ON E.id_empleado = V.id_empleado;
GO

-- ==========================================
-- CONSULTA PROVEEDOR
-- ==========================================

SELECT
P.id_proveedor,
P.nombre_empresa,
C.id_compra,
C.total_compra
FROM Proveedor P
LEFT JOIN Compra C
ON P.id_proveedor = C.id_proveedor;
GO

-- ==========================================
-- CONSULTA CATEGORIA
-- ==========================================

SELECT
C.id_categoria,
C.nombre_categoria,
P.nombre AS Producto,
P.precio
FROM Categoria C
LEFT JOIN Producto P
ON C.id_categoria = P.id_categoria;
GO




-- ==========================================
-- CONSULTA PRODUCTO
-- ==========================================

SELECT
P.nombre,
C.nombre_categoria,
P.precio,
P.stock
P.fecha_Vencimiento
FROM Producto P
INNER JOIN Categoria C
ON P.id_categoria = C.id_categoria;
GO



-- ==========================================
-- CONSULTA VENTA
-- ==========================================

SELECT
V.id_venta,
CL.nombre + ' ' + CL.apellido AS Cliente,
E.nombre AS Empleado,
V.total,
V.metodo_pago
FROM Venta V
INNER JOIN Cliente CL
ON V.id_cliente = CL.id_cliente
INNER JOIN Empleado E
ON V.id_empleado = E.id_empleado;
GO


-- ==========================================
-- CONSULTA DETALLEVENTA
-- ==========================================

SELECT
DV.id_detalle_venta,
DV.nombre_producto,
DV.cantidad,
V.id_venta,
V.total
FROM DetalleVenta DV
INNER JOIN Venta V
ON DV.id_venta = V.id_venta;
GO



-- ==========================================
-- CONSULTA COMPRA
-- ==========================================

SELECT
C.id_compra,
P.nombre_empresa,
E.nombre AS Empleado,
C.total_compra
FROM Compra C
INNER JOIN Proveedor P
ON C.id_proveedor = P.id_proveedor
INNER JOIN Empleado E
ON C.id_empleado = E.id_empleado;
GO




-- ==========================================
-- CONSULTA DETALLECOMPRA
-- ==========================================

SELECT
DC.id_detalle_compra,
DC.nombre_producto,
DC.cantidad_compra,
C.id_compra,
C.total_compra
FROM DetalleCompra DC
INNER JOIN Compra C
ON DC.id_compra = C.id_compra;
GO


-- ==========================================
-- TRIGGERS
-- ==========================================

-- ==========================================
-- TRIGGER PARA VALIDAR STOCK
-- ==========================================

CREATE TRIGGER trg_ValidarStock
ON DetalleVenta
AFTER INSERT
AS
BEGIN

IF EXISTS (
SELECT *
FROM inserted I
INNER JOIN Producto P
ON I.id_producto = P.id_producto
WHERE I.cantidad > P.stock
)
BEGIN
RAISERROR('No hay existencias suficientes', 16, 1);
ROLLBACK TRANSACTION;
END
END;
GO
-- ==========================================
-- TRIGGER PARA VENTA
-- RESTA PRODUCTOS DEL STOCK
-- ==========================================

CREATE TRIGGER trg_VentaStock
ON Detalleventa
AFTER INSERT
AS
BEGIN

UPDATE Producto
SET stock = stock - cantidad
FROM Producto P
INNER JOIN inserted I
ON P.id_producto = I.id_producto;
END;
GO

-- ==========================================
-- TRIGGER PARA COMPRA
-- SUMA PRODUCTOS AL STOCK
-- ==========================================

CREATE TRIGGER trg_CompraStock
ON DetalleCompra
AFTER INSERT
AS
BEGIN

UPDATE Producto
SET stock = stock + cantidad_compra
FROM Producto P
INNER JOIN inserted I
ON P.nombre = I.nombre_producto;
END;
GO
