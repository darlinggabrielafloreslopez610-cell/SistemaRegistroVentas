/*=============================================
  RESPALDOS / BACKUP / RESTORE CON TABLA PRODUCTO
  SistemaRegistroDeVentasBD
=============================================*/

/*=========== 1. RESPALDO COMPLETO INICIAL ===========*/
BACKUP DATABASE SistemaRegistroDeVentasBD
TO DISK = 'C:\Respaldo Sistema de Registro de venta\SistemaRegistroDeVentasBD_Completo.bak'
WITH FORMAT,
     NAME = 'COMPLETO',
     DESCRIPTION = 'RESPALDO COMPLETO',
     COMPRESSION;
GO

--- PRUEBA LUNES ---
INSERT INTO SistemaRegistroDeVentasBD.dbo.Producto (nombre, precio, stock) 
VALUES ('Arroz', 25.50, 100);
GO

/*=========== 2. RESPALDO TRANSACCIONAL (LOG) ===========*/
BACKUP LOG SistemaRegistroDeVentasBD
TO DISK = 'C:\Respaldo Sistema de Registro de venta\SistemaRegistroDeVentasBD_Log.bak'
WITH NAME = 'LOG',
     DESCRIPTION = 'LUNES LOG',
     COMPRESSION;
GO

--- PRUEBA MARTES ---
INSERT INTO SistemaRegistroDeVentasBD.dbo.Producto (nombre, precio, stock) 
VALUES ('Frijoles', 30.00, 80);
GO

/*=========== 3. RESPALDO DIFERENCIAL ===========*/
BACKUP DATABASE SistemaRegistroDeVentasBD
TO DISK = 'C:\Respaldo Sistema de Registro de venta\SistemaRegistroDeVentasBD_Diff.bak'
WITH DIFFERENTIAL,
     NAME = 'DIFERENCIAL',
     DESCRIPTION = 'SABADO DIFF',
     COMPRESSION;
GO

/*=========== 4. VERIFICAR RESPALDOS ===========*/
RESTORE HEADERONLY 
FROM DISK = 'C:\Respaldo Sistema de Registro de venta\SistemaRegistroDeVentasBD_Completo.bak';
GO


/*=========== 5. RESTAURACIÓN / RESTORE ===========*/

ALTER DATABASE SistemaRegistroDeVentasBD SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
GO

RESTORE DATABASE SistemaRegistroDeVentasBD
FROM DISK = 'C:\Respaldo Sistema de registro de venta\SistemaRegistroDeVentasBD_Completo.bak'
WITH REPLACE,
     RECOVERY;
GO


ALTER DATABASE SistemaRegistroDeVentasBD SET MULTI_USER;
GO