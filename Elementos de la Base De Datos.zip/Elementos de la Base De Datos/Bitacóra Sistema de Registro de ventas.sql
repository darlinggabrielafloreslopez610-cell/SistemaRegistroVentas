USE SistemaRegistroDeVentasBD;
GO

-- Crear la tabla de auditoría / bitácora
CREATE TABLE BitacoraMovimientos (
    idBitacora INT IDENTITY(1,1) PRIMARY KEY,
    tablaAfectada VARCHAR(50),      
    accion VARCHAR(20),             
    detalle NVARCHAR(500),          
    usuarioBD VARCHAR(100),         
    fechaHora DATETIME DEFAULT GETDATE()
);
GO


SELECT * FROM BitacoraMovimientos ORDER BY fechaHora DESC;