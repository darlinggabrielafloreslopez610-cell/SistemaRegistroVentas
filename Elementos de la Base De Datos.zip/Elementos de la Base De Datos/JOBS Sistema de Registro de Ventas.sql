USE msdb;
GO

-- 1. Crear el Job programado
EXEC dbo.sp_add_job 
    @job_name = N'Job_Respaldo_Sistema_Ventas';

-- 2. Agregar el paso que ejecutará la copia de seguridad
EXEC dbo.sp_add_jobstep 
    @job_name = N'Job_Respaldo_Sistema_Ventas',
    @step_name = N'Paso_Respaldar_BD',
    @subsystem = N'TSQL',
    @command = N'
    BACKUP DATABASE SistemaRegistroDeVentasBD
    TO DISK = ''C:\Respaldo Sistema de registro de venta\SistemaRegistroDeVentasBD_Completo.bak''
    WITH INIT, COMPRESSION;
    ',
    @retry_attempts = 3,
    @retry_interval = 5;

-- 3. Asignar el servidor local
EXEC dbo.sp_add_jobserver 
    @job_name = N'Job_Respaldo_Sistema_Ventas', 
    @server_name = N'(local)';
GO

-- 4. Programar para todos los domingos a las 12:00 medianoche (00:00:00 hrs)
EXEC dbo.sp_add_jobschedule
    @job_name = N'Job_Respaldo_Sistema_Ventas',
    @name = N'Programacion_Domingos_Medianoche',
    @freq_type = 8,             
    @freq_interval = 1,         
    @freq_recurrence_factor = 1,
    @active_start_time = 000000;
GO