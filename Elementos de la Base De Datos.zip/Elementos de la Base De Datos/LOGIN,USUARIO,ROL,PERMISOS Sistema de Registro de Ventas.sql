USE SistemaRegistroDeVentasBD;
GO

/* ==========================================================
   PASO 1: Crear el Login 
   ========================================================== */
CREATE LOGIN Darling WITH PASSWORD = '1234';
GO

/* ==========================================================
   PASO 2: Crear el Usuario dentro de la base de datos
   
   ========================================================== */
CREATE USER Darling FOR LOGIN Darling;
GO

/* ==========================================================
   PASO 3: Crear el Rol de Seguridad 
   ========================================================== */
CREATE ROLE RolEmpleado;
GO

/* ==========================================================
   PASO 4: Otorgar los permisos específicos al Rol
   ( consultar productos y registrar ventas)
   ========================================================== */
GRANT SELECT ON Producto TO RolEmpleado;
GRANT INSERT ON Venta TO RolEmpleado;
GO

/* ==========================================================
   PASO 5: Agregar el usuario al Rol
   
   ========================================================== */
ALTER ROLE RolEmpleado ADD MEMBER Darling;
GO